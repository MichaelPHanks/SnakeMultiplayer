﻿
using var game = new Client.ClientMain();
game.Run();
