﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    public enum GameStateEnum 
    { 
        MainMenu,
        Settings,
        GamePlay,
        HighScores,
        Help,
        About,
        Exit,
        EnterName,
        Tutorial,
        Controls,


        
    }
}
